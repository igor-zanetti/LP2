﻿namespace Pmatrizes
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLer1 = new System.Windows.Forms.Button();
            this.btnLer2 = new System.Windows.Forms.Button();
            this.btnVariavel = new System.Windows.Forms.Button();
            this.btnArray = new System.Windows.Forms.Button();
            this.btnMedia = new System.Windows.Forms.Button();
            this.btnNome = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnLer1
            // 
            this.btnLer1.Location = new System.Drawing.Point(101, 99);
            this.btnLer1.Name = "btnLer1";
            this.btnLer1.Size = new System.Drawing.Size(154, 66);
            this.btnLer1.TabIndex = 0;
            this.btnLer1.Text = "Ler 20 números e inverter";
            this.btnLer1.UseVisualStyleBackColor = true;
            this.btnLer1.Click += new System.EventHandler(this.btnLer1_Click);
            // 
            // btnLer2
            // 
            this.btnLer2.Location = new System.Drawing.Point(281, 99);
            this.btnLer2.Name = "btnLer2";
            this.btnLer2.Size = new System.Drawing.Size(154, 66);
            this.btnLer2.TabIndex = 1;
            this.btnLer2.Text = "Ler quant. e preço de mercadorias";
            this.btnLer2.UseVisualStyleBackColor = true;
            this.btnLer2.Click += new System.EventHandler(this.btnLer2_Click);
            // 
            // btnVariavel
            // 
            this.btnVariavel.Location = new System.Drawing.Point(101, 184);
            this.btnVariavel.Name = "btnVariavel";
            this.btnVariavel.Size = new System.Drawing.Size(154, 64);
            this.btnVariavel.TabIndex = 2;
            this.btnVariavel.Text = "Variável total";
            this.btnVariavel.UseVisualStyleBackColor = true;
            this.btnVariavel.Click += new System.EventHandler(this.btnVariavel_Click);
            // 
            // btnArray
            // 
            this.btnArray.Location = new System.Drawing.Point(281, 184);
            this.btnArray.Name = "btnArray";
            this.btnArray.Size = new System.Drawing.Size(154, 64);
            this.btnArray.TabIndex = 3;
            this.btnArray.Text = "ArrayList";
            this.btnArray.UseVisualStyleBackColor = true;
            this.btnArray.Click += new System.EventHandler(this.btnArray_Click);
            // 
            // btnMedia
            // 
            this.btnMedia.Location = new System.Drawing.Point(101, 268);
            this.btnMedia.Name = "btnMedia";
            this.btnMedia.Size = new System.Drawing.Size(154, 64);
            this.btnMedia.TabIndex = 4;
            this.btnMedia.Text = "Media aluno";
            this.btnMedia.UseVisualStyleBackColor = true;
            this.btnMedia.Click += new System.EventHandler(this.btnMedia_Click);
            // 
            // btnNome
            // 
            this.btnNome.Location = new System.Drawing.Point(281, 268);
            this.btnNome.Name = "btnNome";
            this.btnNome.Size = new System.Drawing.Size(154, 64);
            this.btnNome.TabIndex = 5;
            this.btnNome.Text = "Nomes pessoas";
            this.btnNome.UseVisualStyleBackColor = true;
            this.btnNome.Click += new System.EventHandler(this.btnNome_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 409);
            this.Controls.Add(this.btnNome);
            this.Controls.Add(this.btnMedia);
            this.Controls.Add(this.btnArray);
            this.Controls.Add(this.btnVariavel);
            this.Controls.Add(this.btnLer2);
            this.Controls.Add(this.btnLer1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private Button btnLer1;
        private Button btnLer2;
        private Button btnVariavel;
        private Button btnArray;
        private Button btnMedia;
        private Button btnNome;
    }
}