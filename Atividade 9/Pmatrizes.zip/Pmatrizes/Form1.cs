using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLer1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string aux;
            for (int i = 0; i < 20; i++)
            {
                aux = Interaction.InputBox("Digite N�mero", "Entrada de Dados");
                if (!Int32.TryParse(aux, out vetor[i]))
                {
                    MessageBox.Show("Dado Inv�lido");
                    i--;
                }
            }
            aux = "";
            for (var i = 19; i >= 0; i--)
            {
                aux = aux + vetor[i] + "\n";
            }
            MessageBox.Show(aux);
        }

        private void btnLer2_Click(object sender, EventArgs e)
        {
            double faturamento = 0;
            double[] qtd = new double[10];
            double[] vlr = new double[10];
            string auxiliar = " ";
            for (var i = 0; i < 10; i++)
            {
                auxiliar = Interaction.InputBox("Digite quantidade" + (i + 1), "Entrada de Quantidades");
                if (!Double.TryParse(auxiliar, out qtd[i]))
                {
                    MessageBox.Show("Quantidade inv�lida");
                    i--;
                }
                else
                {
                    while (vlr[i] <= 0)
                    {
                        auxiliar = " ";
                        auxiliar = Interaction.InputBox("Digite o valor da mercadoria" + (i + 1), "Entrada de Pre�os");
                        if (Double.TryParse(auxiliar, out vlr[i]))
                        {
                            MessageBox.Show("Pre�o inv�lido");
                        }
                    }
                    faturamento += qtd[1] * vlr[1];
                    {
                        MessageBox.Show(faturamento.ToString("N2"));
                    }
                }
            }
        }

        private void btnVariavel_Click(object sender, EventArgs e)
        {
            string[] Alunos = { "Igor", "Gabriel", "Lucas", "John", "Guilherme", "Jo�o" };
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;

            for (I = 0; I < N; I++)
            {
                Total = +Alunos[I].Length;
                MessageBox.Show(Total.ToString("N2"));
            }

        }

        private void btnArray_Click(object sender, EventArgs e)
        {
            List<string> Nomes = new List<string>()
            {"Igor", "Andr�", "Gabriel", "F�tima", "Jo�o", "Janete", "Pedro", "Marcelo", "Pedro", "Thais"};

            Nomes.Remove("Pedro");

            for (int i = 0; i < Nomes.Count; i++)
            {
                MessageBox.Show(Nomes[i]);
            }
        }

        private void btnNome_Click(object sender, EventArgs e)
        {
            double valid = 0;
            string RaEsc;
            int Ra;

            RaEsc = Interaction.InputBox("Digite o seu RA ", "Entrada de dados");

            if (double.TryParse(RaEsc, out valid))
            {
                RaEsc = RaEsc.Substring(RaEsc.Length - 1, 1);
            }
            else
            {
                MessageBox.Show("RA inv�lido!");
            }
            int.TryParse(RaEsc, out Ra);

            if (Ra == 0)
            {
                Ra = 10;
            }
            string[] nomes = new string[Ra];
            string[] auxiliar = new string[Ra];
            int[] compr = new int[Ra];

            for (var i = 0; i < Ra; i++)
            {
                nomes[i] = Interaction.InputBox("Digite o nome completo " + (i + 1), "Entrada de dados");
                if (double.TryParse(nomes[i], out valid))
                {
                    MessageBox.Show("Somente Letras!");
                    i--;
                }
                else
                {
                    auxiliar[i] = nomes[i].Replace(" ", "");
                    compr[i] = auxiliar[i].Length;
                    MessageBox.Show("O nome: " + nomes[i] + " tem " + compr[i] + " caracteres");
                }
            }
        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            double[,] Notas = new double[20, 3];
            double media = 0;
            string stringona;

            for (int i = 0; i < 20; i++)
                for (int j = 0; j < 3; j++)
                {
                    stringona = Interaction.InputBox("Digite a nota " + (j + 1) + " do aluno " + (i + 1), "Entrada de Dados");

                    if (!double.TryParse(stringona, out Notas[i, j]))
                    {
                        MessageBox.Show("Nota Inv�lida \nDigite Novamente");
                        i--;
                    }
                    else
                    {
                        if (!(Notas[i, j] >= 0) && (Notas[i, j] <= 10))
                        {
                            MessageBox.Show("Nota Inv�lida \nDigite Novamente");
                            j--;
                        }
                        else
                        {
                            media = (Notas[i, 0] + Notas[i, 1] + Notas[i, 2]) / 3;
                            MessageBox.Show("Aluno " + (i + 1) + " M�dia: " + media.ToString("N2"));
                        }
                    }
                }
        }
    }
}