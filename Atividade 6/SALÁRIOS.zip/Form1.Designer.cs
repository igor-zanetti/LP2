﻿namespace PSalarios
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.lblBruto = new System.Windows.Forms.Label();
            this.lblFilhos = new System.Windows.Forms.Label();
            this.mskbxSalBruto = new System.Windows.Forms.MaskedTextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.cbxNumFilhos = new System.Windows.Forms.ComboBox();
            this.btnVerifica = new System.Windows.Forms.Button();
            this.lblAliquotaINSS = new System.Windows.Forms.Label();
            this.lblAliquotaIRPF = new System.Windows.Forms.Label();
            this.lblFamilia = new System.Windows.Forms.Label();
            this.lblLiquido = new System.Windows.Forms.Label();
            this.lblDescontoINSS = new System.Windows.Forms.Label();
            this.lblDescontoIRPF = new System.Windows.Forms.Label();
            this.gpbxSexo = new System.Windows.Forms.GroupBox();
            this.rbtnM = new System.Windows.Forms.RadioButton();
            this.rbtnF = new System.Windows.Forms.RadioButton();
            this.ckbxCasado = new System.Windows.Forms.CheckBox();
            this.mskbxAliqINSS = new System.Windows.Forms.MaskedTextBox();
            this.mskbxAliqIRPF = new System.Windows.Forms.MaskedTextBox();
            this.mskbxFamilia = new System.Windows.Forms.MaskedTextBox();
            this.mskbxLiquido = new System.Windows.Forms.MaskedTextBox();
            this.mskbxDescINSS = new System.Windows.Forms.MaskedTextBox();
            this.mskbxDescIRPF = new System.Windows.Forms.MaskedTextBox();
            this.lblDados = new System.Windows.Forms.Label();
            this.gpbxSexo.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(25, 48);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(104, 15);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome funcionário";
            // 
            // lblBruto
            // 
            this.lblBruto.AutoSize = true;
            this.lblBruto.Location = new System.Drawing.Point(25, 82);
            this.lblBruto.Name = "lblBruto";
            this.lblBruto.Size = new System.Drawing.Size(74, 15);
            this.lblBruto.TabIndex = 1;
            this.lblBruto.Text = "Salário bruto";
            // 
            // lblFilhos
            // 
            this.lblFilhos.AutoSize = true;
            this.lblFilhos.Location = new System.Drawing.Point(25, 121);
            this.lblFilhos.Name = "lblFilhos";
            this.lblFilhos.Size = new System.Drawing.Size(99, 15);
            this.lblFilhos.TabIndex = 2;
            this.lblFilhos.Text = "Número de filhos";
            // 
            // mskbxSalBruto
            // 
            this.mskbxSalBruto.Location = new System.Drawing.Point(135, 79);
            this.mskbxSalBruto.Mask = "00000,00";
            this.mskbxSalBruto.Name = "mskbxSalBruto";
            this.mskbxSalBruto.Size = new System.Drawing.Size(100, 23);
            this.mskbxSalBruto.TabIndex = 3;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(135, 45);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 23);
            this.txtNome.TabIndex = 4;
            // 
            // cbxNumFilhos
            // 
            this.cbxNumFilhos.FormattingEnabled = true;
            this.cbxNumFilhos.Location = new System.Drawing.Point(135, 118);
            this.cbxNumFilhos.Name = "cbxNumFilhos";
            this.cbxNumFilhos.Size = new System.Drawing.Size(100, 23);
            this.cbxNumFilhos.TabIndex = 5;
            // 
            // btnVerifica
            // 
            this.btnVerifica.Location = new System.Drawing.Point(51, 170);
            this.btnVerifica.Name = "btnVerifica";
            this.btnVerifica.Size = new System.Drawing.Size(172, 37);
            this.btnVerifica.TabIndex = 6;
            this.btnVerifica.Text = "Verifica desconto";
            this.btnVerifica.UseVisualStyleBackColor = true;
            this.btnVerifica.Click += new System.EventHandler(this.btnVerifica_Click);
            // 
            // lblAliquotaINSS
            // 
            this.lblAliquotaINSS.AutoSize = true;
            this.lblAliquotaINSS.Location = new System.Drawing.Point(28, 272);
            this.lblAliquotaINSS.Name = "lblAliquotaINSS";
            this.lblAliquotaINSS.Size = new System.Drawing.Size(79, 15);
            this.lblAliquotaINSS.TabIndex = 7;
            this.lblAliquotaINSS.Text = "Aliquota INSS";
            // 
            // lblAliquotaIRPF
            // 
            this.lblAliquotaIRPF.AutoSize = true;
            this.lblAliquotaIRPF.Location = new System.Drawing.Point(28, 312);
            this.lblAliquotaIRPF.Name = "lblAliquotaIRPF";
            this.lblAliquotaIRPF.Size = new System.Drawing.Size(78, 15);
            this.lblAliquotaIRPF.TabIndex = 8;
            this.lblAliquotaIRPF.Text = "Aliquota IRPF";
            // 
            // lblFamilia
            // 
            this.lblFamilia.AutoSize = true;
            this.lblFamilia.Location = new System.Drawing.Point(28, 349);
            this.lblFamilia.Name = "lblFamilia";
            this.lblFamilia.Size = new System.Drawing.Size(83, 15);
            this.lblFamilia.TabIndex = 9;
            this.lblFamilia.Text = "Salário Família";
            // 
            // lblLiquido
            // 
            this.lblLiquido.AutoSize = true;
            this.lblLiquido.Location = new System.Drawing.Point(28, 388);
            this.lblLiquido.Name = "lblLiquido";
            this.lblLiquido.Size = new System.Drawing.Size(85, 15);
            this.lblLiquido.TabIndex = 10;
            this.lblLiquido.Text = "Salário Líquido";
            // 
            // lblDescontoINSS
            // 
            this.lblDescontoINSS.AutoSize = true;
            this.lblDescontoINSS.Location = new System.Drawing.Point(433, 267);
            this.lblDescontoINSS.Name = "lblDescontoINSS";
            this.lblDescontoINSS.Size = new System.Drawing.Size(84, 15);
            this.lblDescontoINSS.TabIndex = 17;
            this.lblDescontoINSS.Text = "Desconto INSS";
            // 
            // lblDescontoIRPF
            // 
            this.lblDescontoIRPF.AutoSize = true;
            this.lblDescontoIRPF.Location = new System.Drawing.Point(437, 312);
            this.lblDescontoIRPF.Name = "lblDescontoIRPF";
            this.lblDescontoIRPF.Size = new System.Drawing.Size(83, 15);
            this.lblDescontoIRPF.TabIndex = 18;
            this.lblDescontoIRPF.Text = "Desconto IRPF";
            // 
            // gpbxSexo
            // 
            this.gpbxSexo.Controls.Add(this.rbtnF);
            this.gpbxSexo.Controls.Add(this.rbtnM);
            this.gpbxSexo.Location = new System.Drawing.Point(500, 47);
            this.gpbxSexo.Name = "gpbxSexo";
            this.gpbxSexo.Size = new System.Drawing.Size(91, 100);
            this.gpbxSexo.TabIndex = 19;
            this.gpbxSexo.TabStop = false;
            this.gpbxSexo.Text = "Sexo";
            // 
            // rbtnM
            // 
            this.rbtnM.AutoSize = true;
            this.rbtnM.Checked = true;
            this.rbtnM.Location = new System.Drawing.Point(24, 33);
            this.rbtnM.Name = "rbtnM";
            this.rbtnM.Size = new System.Drawing.Size(36, 19);
            this.rbtnM.TabIndex = 0;
            this.rbtnM.TabStop = true;
            this.rbtnM.Text = "M";
            this.rbtnM.UseVisualStyleBackColor = true;
            // 
            // rbtnF
            // 
            this.rbtnF.AutoSize = true;
            this.rbtnF.Location = new System.Drawing.Point(24, 63);
            this.rbtnF.Name = "rbtnF";
            this.rbtnF.Size = new System.Drawing.Size(31, 19);
            this.rbtnF.TabIndex = 1;
            this.rbtnF.Text = "F";
            this.rbtnF.UseVisualStyleBackColor = true;
            // 
            // ckbxCasado
            // 
            this.ckbxCasado.AutoSize = true;
            this.ckbxCasado.Location = new System.Drawing.Point(512, 170);
            this.ckbxCasado.Name = "ckbxCasado";
            this.ckbxCasado.Size = new System.Drawing.Size(65, 19);
            this.ckbxCasado.TabIndex = 20;
            this.ckbxCasado.Text = "Casado";
            this.ckbxCasado.UseVisualStyleBackColor = true;
            // 
            // mskbxAliqINSS
            // 
            this.mskbxAliqINSS.Enabled = false;
            this.mskbxAliqINSS.Location = new System.Drawing.Point(123, 269);
            this.mskbxAliqINSS.Name = "mskbxAliqINSS";
            this.mskbxAliqINSS.Size = new System.Drawing.Size(100, 23);
            this.mskbxAliqINSS.TabIndex = 21;
            // 
            // mskbxAliqIRPF
            // 
            this.mskbxAliqIRPF.Enabled = false;
            this.mskbxAliqIRPF.Location = new System.Drawing.Point(123, 304);
            this.mskbxAliqIRPF.Name = "mskbxAliqIRPF";
            this.mskbxAliqIRPF.Size = new System.Drawing.Size(100, 23);
            this.mskbxAliqIRPF.TabIndex = 22;
            // 
            // mskbxFamilia
            // 
            this.mskbxFamilia.Enabled = false;
            this.mskbxFamilia.Location = new System.Drawing.Point(123, 341);
            this.mskbxFamilia.Name = "mskbxFamilia";
            this.mskbxFamilia.Size = new System.Drawing.Size(100, 23);
            this.mskbxFamilia.TabIndex = 23;
            // 
            // mskbxLiquido
            // 
            this.mskbxLiquido.Enabled = false;
            this.mskbxLiquido.Location = new System.Drawing.Point(123, 380);
            this.mskbxLiquido.Name = "mskbxLiquido";
            this.mskbxLiquido.Size = new System.Drawing.Size(100, 23);
            this.mskbxLiquido.TabIndex = 24;
            // 
            // mskbxDescINSS
            // 
            this.mskbxDescINSS.Enabled = false;
            this.mskbxDescINSS.Location = new System.Drawing.Point(543, 264);
            this.mskbxDescINSS.Name = "mskbxDescINSS";
            this.mskbxDescINSS.Size = new System.Drawing.Size(100, 23);
            this.mskbxDescINSS.TabIndex = 25;
            // 
            // mskbxDescIRPF
            // 
            this.mskbxDescIRPF.Enabled = false;
            this.mskbxDescIRPF.Location = new System.Drawing.Point(543, 304);
            this.mskbxDescIRPF.Name = "mskbxDescIRPF";
            this.mskbxDescIRPF.Size = new System.Drawing.Size(100, 23);
            this.mskbxDescIRPF.TabIndex = 26;
            // 
            // lblDados
            // 
            this.lblDados.AutoSize = true;
            this.lblDados.Location = new System.Drawing.Point(45, 233);
            this.lblDados.Name = "lblDados";
            this.lblDados.Size = new System.Drawing.Size(53, 15);
            this.lblDados.TabIndex = 27;
            this.lblDados.Text = "lblDados";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(753, 442);
            this.Controls.Add(this.lblDados);
            this.Controls.Add(this.mskbxDescIRPF);
            this.Controls.Add(this.mskbxDescINSS);
            this.Controls.Add(this.mskbxLiquido);
            this.Controls.Add(this.mskbxFamilia);
            this.Controls.Add(this.mskbxAliqIRPF);
            this.Controls.Add(this.mskbxAliqINSS);
            this.Controls.Add(this.ckbxCasado);
            this.Controls.Add(this.gpbxSexo);
            this.Controls.Add(this.lblDescontoIRPF);
            this.Controls.Add(this.lblDescontoINSS);
            this.Controls.Add(this.lblLiquido);
            this.Controls.Add(this.lblFamilia);
            this.Controls.Add(this.lblAliquotaIRPF);
            this.Controls.Add(this.lblAliquotaINSS);
            this.Controls.Add(this.btnVerifica);
            this.Controls.Add(this.cbxNumFilhos);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.mskbxSalBruto);
            this.Controls.Add(this.lblFilhos);
            this.Controls.Add(this.lblBruto);
            this.Controls.Add(this.lblNome);
            this.Name = "Form1";
            this.Text = "Form1";
            this.gpbxSexo.ResumeLayout(false);
            this.gpbxSexo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblNome;
        private Label lblBruto;
        private Label lblFilhos;
        private MaskedTextBox mskbxSalBruto;
        private TextBox txtNome;
        private ComboBox cbxNumFilhos;
        private Button btnVerifica;
        private Label lblAliquotaINSS;
        private Label lblAliquotaIRPF;
        private Label lblFamilia;
        private Label lblLiquido;
        private Label lblDescontoINSS;
        private Label lblDescontoIRPF;
        private GroupBox gpbxSexo;
        private RadioButton rbtnF;
        private RadioButton rbtnM;
        private CheckBox ckbxCasado;
        private MaskedTextBox mskbxAliqINSS;
        private MaskedTextBox mskbxAliqIRPF;
        private MaskedTextBox mskbxFamilia;
        private MaskedTextBox mskbxLiquido;
        private MaskedTextBox mskbxDescINSS;
        private MaskedTextBox mskbxDescIRPF;
        private Label lblDados;
    }
}