namespace PSalarios
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerifica_Click(object sender, EventArgs e)
        {
            double descontoINSS = 0;
            double descontoIRPF = 0;
            double salarioLiquido = 0;
            double salarioBruto = 0;
            double salarioFamilia = 0;
            double numeroFilhos = 0;

            if (txtNome = string.Empty()) // vazio
            {
                MessageBox.Show("O nome do usu�rio" + "\n n�o pode ser vazio!");
            }
            if (mskbxSalBruto.Text.Replace(",", "").Trim() == "")
                    MessageBox.Show("N�o digitou o sal�rio");


                if (!double.TryParse(mskbxSalBruto.Text, out salarioBruto) ||
                    !double.TryParse(cbxNumFilhos.Text, out numeroFilhos))
                {
                    MessageBox.Show("Sal�rio bruto e n�mero de filhos devem ser num�ricos!");
                    {
                
                        {
                            if (salarioBruto <= 0)
                                MessageBox.Show("S�lario deve ser maio que 0");
                            else
                            {
                                //C�lculo para INSS
                                if (salarioBruto <= 800.47)
                                {
                                    mskbxAliqINSS.Text = "7,65%";
                                    descontoINSS = 0.0765 * salarioBruto;
                                }
                                else if (salarioBruto <= 1050)
                                {
                                    mskbxAliqINSS.Text = "8,65%";
                                    descontoINSS = ((8.65 / 100) * salarioBruto);
                                }
                                else if (salarioBruto <= 1400.77)
                                {
                                    mskbxAliqINSS.Text = "9,00%";
                                    descontoINSS = ((9 / 100) * salarioBruto);
                                }
                                else if (salarioBruto <= 2801.56)
                                {
                                    mskbxAliqINSS.Text = "11,00%";
                                    descontoINSS = 0.11 * salarioBruto;
                                }
                                else
                                {
                                    mskbxAliqINSS = "teto";
                                    descontoINSS = 308.17;
                                }

                                mskbxDescINSS.Text = descontoINSS.ToString("N2");

                                //Desconto imposto de renda
                                if (salarioBruto < +1257.12)
                                    mskbxAliqIRPF.Text = "0";
                                else if (salarioBruto <= 2512.08)
                                {
                                    mskbxAliqIRPF.Text = "15%";
                                    descontoIRPF = (salarioBruto * 15 / 100);
                                }
                                else
                                {
                                    mskbxAliqINSS.Text = "27,5%";
                                    descontoIRPF = (salarioBruto * 27.5 / 100);
                                }

                                mskbxDescIRPF.Text = descontoIRPF.ToString("N2");

                                //Sal�rio fam�lia
                                if (numeroFilhos > 0)
                                {
                                    if (salarioBruto <= 435.52)
                                        salarioFamilia = (22.33 * numeroFilhos);
                                    else if (salarioBruto <= 654.61)
                                        salarioFamilia = (15.74 * numeroFilhos);
                                    else
                                        salarioFamilia = 0;
                                }

                                mskbxFamilia.Text = salarioFamilia.ToString("N2");

                                salarioLiquido = salarioFamilia - descontoINSS - descontoIRPF - salarioBruto;

                                mskbxLiquido.Text = salarioLiquido.ToString("N2");

                            lblDados.Text = "Os descontos do sal�rio" + (rbtnF.Checked ? "da Sra." : "do Sr.") +
                                 txtNome + "\n" + "que �" + (ckbxCasado.Checked ? "Casado(a)" : "Solteiro(a)") +
                                 "\n" + "e que tem" + Convert.ToString(numeroFilhos) + "filho(s) s�o:";

                            lblDados.Text = "Os descontos do sal�rio";

                            if (rbtnF.Checked)
                                lblDados.Text = lblDados.Text + "da Sra";
                            else
                                lblDados.Text + "do Sr";

                            lblDados.Text = lblDados.Text + txtNome.Text;

                            if (ckbxCasado.Checked)
                                lblDados.Text += "que � casado(a)";
                            else
                                lblDados.Text = lblDados.Text + "que � solteiro(a)";

                            }

                        }
                    }
                }

            }
         
               
            }
        }

    