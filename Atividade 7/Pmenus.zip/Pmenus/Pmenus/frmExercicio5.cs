﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmenus
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnVerifica_Click(object sender, EventArgs e)
        {
            int num1, num2, num;

            if (!int.TryParse(txtnum1.Text, out num1) ||
                !int.TryParse(txtnum2.Text, out num2))
            {
                MessageBox.Show("Coloque Números!");
            }
            else
            {
                Random rnd = new Random();
                num = rnd.Next(num1, num2);
                string nums = num.ToString();
                MessageBox.Show(nums);
            }
        }
    }
}
