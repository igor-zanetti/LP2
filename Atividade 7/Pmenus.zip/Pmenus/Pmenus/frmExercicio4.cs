﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmenus
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int cont = 0;

            for (var i = 0; i < RTB.Text.Length; i++)
            {
                if (char.IsNumber(RTB.Text, i))
                {
                    cont++;
                }
            }

            MessageBox.Show("Existe " + cont + " números nesse texto");

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int EB = -1, cont = 0;

            while (cont < RTB.Text.Length)
            {
                if (Char.IsWhiteSpace(RTB.Text[cont]))
                {
                    EB = cont;
                    break;
                }

                cont++;
            }
            MessageBox.Show("O primeiro espaço é: " + EB);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int cont = 0;

            foreach (char c in RTB.Text)
            {
                if (char.IsLetter(RTB.Text, cont))
                {
                    cont++;
                }
            }

            MessageBox.Show("Tem um total de: " + cont + " letras");

        }
    }
    }
    
    



