﻿namespace Pmenus
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RTB = new System.Windows.Forms.RichTextBox();
            this.btnNUM = new System.Windows.Forms.Button();
            this.btnBRANCO = new System.Windows.Forms.Button();
            this.btnALFABETICOS = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // RTB
            // 
            this.RTB.Location = new System.Drawing.Point(149, 33);
            this.RTB.Name = "RTB";
            this.RTB.Size = new System.Drawing.Size(203, 100);
            this.RTB.TabIndex = 0;
            this.RTB.Text = "";
            // 
            // btnNUM
            // 
            this.btnNUM.Location = new System.Drawing.Point(68, 213);
            this.btnNUM.Name = "btnNUM";
            this.btnNUM.Size = new System.Drawing.Size(99, 45);
            this.btnNUM.TabIndex = 1;
            this.btnNUM.Text = "Numéricos";
            this.btnNUM.UseVisualStyleBackColor = true;
            this.btnNUM.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnBRANCO
            // 
            this.btnBRANCO.Location = new System.Drawing.Point(213, 213);
            this.btnBRANCO.Name = "btnBRANCO";
            this.btnBRANCO.Size = new System.Drawing.Size(108, 44);
            this.btnBRANCO.TabIndex = 2;
            this.btnBRANCO.Text = "Posição Primeiro espaço em branco";
            this.btnBRANCO.UseVisualStyleBackColor = true;
            this.btnBRANCO.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnALFABETICOS
            // 
            this.btnALFABETICOS.Location = new System.Drawing.Point(377, 213);
            this.btnALFABETICOS.Name = "btnALFABETICOS";
            this.btnALFABETICOS.Size = new System.Drawing.Size(115, 45);
            this.btnALFABETICOS.TabIndex = 3;
            this.btnALFABETICOS.Text = "Alfabéticos";
            this.btnALFABETICOS.UseVisualStyleBackColor = true;
            this.btnALFABETICOS.Click += new System.EventHandler(this.button3_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(562, 297);
            this.Controls.Add(this.btnALFABETICOS);
            this.Controls.Add(this.btnBRANCO);
            this.Controls.Add(this.btnNUM);
            this.Controls.Add(this.RTB);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox RTB;
        private System.Windows.Forms.Button btnNUM;
        private System.Windows.Forms.Button btnBRANCO;
        private System.Windows.Forms.Button btnALFABETICOS;
    }
}